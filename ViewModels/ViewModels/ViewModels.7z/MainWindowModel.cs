﻿using PropertyChanged;
using ReactiveUI;
using Services;
using Splat;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Text;

namespace ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public sealed class MainWindowModel : BaseViewModel
    {
        public bool IsInitialized { get; set; }
        public string Title { get; set; } = "123";
        private readonly ObservableAsPropertyHelper<IEnumerable<RxPhone>> _phones;
        private readonly ObservableAsPropertyHelper<int> _countPhones;
        public IEnumerable<RxPhone> Phones => _phones.Value;
        public int CountPhones => _countPhones.Value;
        private readonly ObservableAsPropertyHelper<bool> _isLoading;
        public bool IsLoading => _isLoading.Value;
        //public IEnumerable<RxPhone> Phones { get; set; }
        public RxPhone SelectedPhone { get; set; }
        public ReactiveCommand<Unit, Unit> ExitCommand { get; set; }
        public ReactiveCommand<Unit, IEnumerable<Phone>> RefreshCommand { get; set; }
        public ReactiveCommand<Unit, Unit> TestCommand { get; set; }
        public MainWindowModel()
        {
            IPhoneRepositoryAsync r = Locator.Current.GetService<IPhoneRepositoryAsync>();
            RefreshCommand = ReactiveCommand.CreateFromTask(() => r.GetAllAsEnumerable(), null, RxApp.MainThreadScheduler);
            RefreshCommand.IsExecuting.ToProperty(this, x => x.IsLoading, out _isLoading);
            _phones = RefreshCommand
                .Select(phones => phones.Select(phone => new RxPhone(phone.Id, phone.Title)))
                .ObserveOn(RxApp.MainThreadScheduler)
                .ToProperty(this, x => x.Phones);
            this.WhenAnyValue(vm => vm.Phones)
                .Where(x => x != null)
                .Select(list => list.Count())
                .ObserveOn(RxApp.MainThreadScheduler)
                .ToProperty(source: this, property: vm => vm.CountPhones, result: out _countPhones, initialValue: 0);
            var controller = new MainWindowController(this);            
            this.WhenActivated(disposables =>
            {
              //  controller.BindExitCommand().DisposeWith(disposables);
              //  controller.BindTestCommand().DisposeWith(disposables);
                controller.BindWindowTitle().DisposeWith(disposables);
               // controller.BindRefreshCommand().DisposeWith(disposables);
              //  TestCommand.Execute().Subscribe();
                // controller.BindListPhones().DisposeWith(disposables);
             //   RefreshCommand.Execute().Subscribe().DisposeWith(disposables);
                var t = 0;
            });
            var g = 0;
        }                
        
        //private IDisposable BindNodes()
        //        {
        //            return Nodes.Connect()
        //                .SubscribeOn(RxApp.TaskpoolScheduler)
        //                .ObserveOn(RxApp.MainThreadScheduler)
        //                .Bind(Items)
        //                .SubscribeWithLog();
        //        }
    }
}
