﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViewModels
{
    public sealed class EditViewModel
    {
    }
}
